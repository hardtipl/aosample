import React from "react";
import { useNavigate } from "react-router-dom";
import "./header.css"
import { Link } from "react-router-dom";
import { useState } from "react";

const Header = ({ usertype }) => {


  const [open, setopen] = useState(false);


  const navigate = useNavigate();


  const handleLogout = () => {
    localStorage.clear();

    navigate("/login");
  };


  return (
    <>
      <>
        <nav className="navbar navbar-dark bg-dark">
          <div className="container-fluid">
            {!open ? <button
              className="navbar-toggler "
              type="button"
              data-mdb-toggle="collapse"
              data-mdb-target="#navbarToggleExternalContent2"
              aria-controls="navbarToggleExternalContent2"
              aria-expanded="false"
              aria-label="Toggle navigation"
              onClick={() => {
                setopen(true);
              }}
            >

              <i className="fas fa-bars"></i>
              <div className="container" >
                <div className="bar1"></div>
                <div className="bar2"></div>
                <div className="bar3"></div>
              </div>
            </button> :

              <button
                className="navbar-toggler "
                type="button"
                data-mdb-toggle="collapse"
                data-mdb-target="#navbarToggleExternalContent2"
                aria-controls="navbarToggleExternalContent2"
                aria-expanded="false"
                aria-label="Toggle navigation"
                onClick={() => {
                  setopen(false);
                }}
              >

                <i className="fas fa-bars"></i>
                <div className="container" >
                  <div className="bar1"></div>
                  <div className="bar2"></div>
                  <div className="bar3"></div>
                </div>
              </button>

            }

{open&&usertype == "Sales" &&

              <div style={{ width: "30%", height: "150%", zIndex: "100000" ,marginRight:"auto"}} >
                <ul className="navlist" style={{ display: "inline-flex " }}>
                <Link to="/sales_dash" style={{ color: "white", padding: "0 15px" }}> <li  > Dashboard</li></Link>
                <Link to="/inquiry_list" style={{ color: "white", padding: "0 15px" }}> <li> Inquiries</li></Link>
                <Link to="/project_list" style={{ color: "white", padding: "0 15px" }}> <li> Projects</li></Link>
                <Link to="/lead_list" style={{ color: "white", padding: "0 15px" }}> <li> Leads</li></Link>
                </ul>
              </div>

            }


            {usertype == "Sales" && <span>


              <a href="/inquiry" className="li-link mx-4"> Create Inquiry</a>

              <button onClick={handleLogout}><a href="#" className="btn btn-light">Logout</a></button>
            </span>}

            {open&&usertype == "Admin" &&

              <div style={{ width: "30%", height: "150%", zIndex: "100000" ,marginRight:"auto"}} >
                <ul className="navlist" style={{ display: "inline-flex " }}>
                  <Link to="/admind" style={{ color: "white", padding: "0 15px" }}> <li > Dashboard</li></Link>
                  <Link to="/inquiry_list" style={{ color: "white", padding: "0 15px" }}> <li> Inquiries</li></Link>
                  <Link to="/project_list" style={{ color: "white", padding: "0 15px" }}> <li> Projects</li></Link>
                  <Link to="/lead_list" style={{ color: "white", padding: "0 15px" }}> <li> Leads</li></Link>
                </ul>
              </div>

            }
            {usertype == "Admin" && <span>


              <a href="/register" className="li-link mx-4">Register User</a>
              <a href="/inquiry" className="li-link mx-4">Create Inquiry</a>

              <button onClick={handleLogout}><a href="#" className="btn btn-light ">Logout</a></button>
            </span>}


            {open&&usertype == "Developer" &&

              <div style={{ width: "30%", height: "150%", zIndex: "100000" ,marginRight:"auto"}} >
                <ul className="navlist" style={{ display: "inline-flex " }}>
                <Link to="/devdash"  style={{ color: "white", padding: "0 15px" }}> <li> Dashboard</li></Link>
                <Link to="/dev_task"  style={{ color: "white", padding: "0 15px" }}> <li> Tasks</li></Link>
                </ul>
              </div>

            }

            {usertype == "Developer" && <span>




              <button onClick={handleLogout}><a href="#" className="btn btn-light">Logout</a></button>
            </span>}
          </div>
        </nav>

        {/* {open && (
          <>
            {usertype == "Sales" && <div style={{ position: "absolute", padding: "35px 0", width: "12%", height: "150%", zIndex: "100000" }} className="bg-dark">
              <ul className="navlist ">

                <Link to="/sales_dash" style={{ color: "white" }}> <li  > Dashboard</li></Link>
                <Link to="/inquiry_list" style={{ color: "white" }}> <li> Inquiries</li></Link>
                <Link to="/project_list" style={{ color: "white" }}> <li> Projects</li></Link>
                <Link to="/lead_list" style={{ color: "white" }}> <li> Leads</li></Link>
              </ul>
            </div>}

            {usertype == "Developer" && <div style={{ position: "absolute", padding: "35px 0", width: "12%", height: "150%", zIndex: "100000" }} className="bg-dark">
              <ul className="navlist ">
                <Link to="/devdash" style={{ color: "white" }}> <li> Dashboard</li></Link>
                <Link to="/dev_task" style={{ color: "white" }}> <li> Tasks</li></Link>
              </ul>
            </div>}
          </>
        )} */}


      </>
    </>
  )
}


export default Header