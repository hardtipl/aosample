import React, { useState } from "react";
import "./reports.css"
import { useEffect } from "react";
import { Link } from "react-router-dom";
import Select from "react-select";
import axios from "axios";
const Reports = () => {
  const [searchfilter, setSearchfilter] = useState({
    serchon: "Sales",
    technology: "",
    title: "",
    users: undefined
  });
  const [options, setOptions] = useState([])
  const [ok, setOk] = useState("")
  const [StartDate, setStartDate] = useState("")
  const [EndDate, setEndDate] = useState("")
  // const [isActive, setActive] = useState(false);
  const [selecteproject, setSelecteproject] = useState(false);
  const handleChange = (e) => {
    let name = e.target.name
    let value = e.target.value
    setSearchfilter({ ...searchfilter, [name]: value })
  }

  // const [pageCount, setpageCount] = useState(0);
  // const [itemOffset, setItemOffset] = useState(0);
  const [defaultview, setDefaultview] = useState('Income');
  const [income, setIncome] = useState([])
  const [expense, setExpense] = useState([])
  // let itemPerPage = 10;

  const [data, setData] = useState()

useEffect(()=>{
return  ()=>{
  setDefaultview('')
}
},[])
  const apicall = async () => {
    let apiurl = `${process.env.REACT_APP_APIURL}/reports/detailreport?`
    // if(itemOffset>0){

    //   apiurl=  `${apiurl}offset=${itemOffset} &`
    // } 
    if (searchfilter.serchon) { apiurl = `${apiurl}searchon=${searchfilter.serchon}&` }
    if (StartDate?.length > 0) {
      apiurl = `${apiurl}startingdate=${StartDate}&`
    }
    if (EndDate?.length > 0) {
      apiurl = `${apiurl}endingdate=${EndDate}&`
    }
    if (selecteproject) apiurl = `${apiurl}projectid=${selecteproject.value}&`
    // alert(apiurl)
    const hitcall = await fetch(
      apiurl,
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("Token")}`,
        },
      }

    )
    const result = await hitcall.json()
    console.log(result)

    let check = result.Message
    console.log(check)
    if (searchfilter.serchon == "Transaction") {
      check = result.Message
      setExpense(check.expense)
      setIncome(check.income)
    }
    else if (searchfilter.serchon == "Sales") {
      let useridlist = []
      let datalist = []
      for (const saleslist of check.fetchingonsales) {
        debugger
        console.log(saleslist)
        if (!useridlist.includes(saleslist.userid)) {
          useridlist.push(saleslist.userid)
          datalist.push({ id: saleslist.userid, username: saleslist.vname })
        }
        else {
          let userid = saleslist.userid
          console.log("userid", userid)
          let updateondetaillist = useridlist.indexOf(userid)
          datalist[updateondetaillist] = { ...datalist[updateondetaillist], ["project_" + saleslist.projecttypeofhire]: saleslist.projectcreated, ["inquiry_" + saleslist.inquirytypeofhire]: saleslist.countofinquiry }
          console.log("updateondetaillist", updateondetaillist)
        }
      }
      console.log("useridlist", useridlist)
      check = datalist
    }
    setData(check)
  }
  useEffect(() => {
    apicall()
  }, [searchfilter,  StartDate, EndDate,selecteproject])

  useEffect(() => {
    console.log(data);
  }, [data]);
  useEffect(() => {
    fetchingprojects()
    return () => {
      // watchShowAge=""
    }
  }, [])
  useEffect(() => {
setSelecteproject('')
  }, [searchfilter])
  // searchfilter

  const handleReset = () => {
    setSearchfilter({
      serchon: "Sales",
      technology: "",
      title: "",
      users: undefined
    })
    setOk("")
    setStartDate("")
    setEndDate("")
  }
  const fetchingprojects = async () => {
    const Projectfetching = await axios.get(
      `${process.env.REACT_APP_APIURL}/projects`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("Token")}`,
      }
    }
    );
    const projectlist = await Projectfetching.data;
    console.log("projectlist", projectlist)
    let listofproject = []
    for (const projects of projectlist?.userid) {
      let createobj = {}
      createobj.value = projects.id
      createobj.label = projects.vTitleProject
      listofproject.push(createobj)
    }
    setOptions(listofproject)
  }
  return (
    <div className="row ">
      <div className="col-2 filter">
        <div className="px-2 py-0">
          <div className="d-flex justify-content-between ">
            <h4 className="text-center"> Filter</h4>

            <u className="text-primary reset" onClick={handleReset}>
              Reset
            </u>

          </div>
          <div className="w-100">
            <input

              type="radio"
              name="serchon"
              onChange={handleChange}
              id=""
              value={"Sales"}
              checked={searchfilter.serchon == "Sales" ? "checked" : ""}
            />

            <label htmlFor="">Sales</label>
          </div>
          <div className="w-100">
            <input
              type="radio"
              onChange={handleChange}
              name="serchon"
              id=""
              value={"Developer"}
              checked={searchfilter.serchon == "Developer" ? "checked" : ""}
            />
            <label htmlFor="">Developer</label>
          </div>
          <div className="w-100">
            <input
              type="radio"
              onChange={handleChange}
              name="serchon"
              id=""
              value={"Transaction"}
              checked={searchfilter.serchon == "Transaction" ? "checked" : ""}
            />
            <label htmlFor="">Transaction</label>
          </div>
          <div className="pt-2 ">
            <h5 className="text-center">Date</h5>
          </div>
          <div>

            <label htmlFor="" className="w-100">Start Date</label>
            <input type="date" className="w-100 rounded-pill px-1" value={StartDate} onChange={(e) => { setStartDate(e.target.value) }} />
          </div>
          <div>
            <label htmlFor="" className="w-100">End Date</label>
            <input type="date" className="w-100 rounded-pill px-1" value={EndDate} onChange={(e) => { setEndDate(e.target.value) }} />
          </div>

        </div>
      </div>
      <div className="col-10">
        <div className="d-flex justify-content-between px-5">
          <h1 className="text-center">Reports Detail</h1>
          <div className="py-2">

          </div>
        </div>
        <div className="py-2">
          <div className="row">
            {searchfilter.serchon == "Transaction" &&defaultview==='Income'&&
              <>
                <div className="col-12">
                  <div className="d-flex justify-content-center">
<button className="col-2">Income</button>
<button className="col-2" onClick={()=>setDefaultview("Expense")}>Expense</button>
                  </div>
                  <div>
                  <h1>Income</h1>
                  <Select
                        defaultValue={selecteproject}
                        onChange={e=>setSelecteproject(e)}
                        options={options}
                      />
                  </div>
                  <table className="table table-bordered">
                    <thead>
                      <tr>
                        <th>Index</th>
                        <th>Projectname</th>
                        <th>Amount</th>
                        <th>Income Came By</th>
                        <th>Currency </th>
                        <th>Currency  Rate</th>
                        <th>Paid Date</th>
                        <th>Document </th>
                      </tr>
                    </thead>
                    <tbody>
                      {/* <tr>
            <td>1</td>
            <td>ok</td>
            <td>1000</td>
            <td>NEFT</td>
            <td>Inr</td>
            <td></td>
            <td></td>
          </tr> */}
                      {
                        income?.map((incomedetail, index) => {
                          console.log(incomedetail)
                          return (
                            <tr>
                              <td>{"Proj" + incomedetail.iProjectid}</td>
                              <td>{incomedetail.projecttitle}</td>
                              <td>{incomedetail.totalmountpaid}</td>
                              <td>{incomedetail.eTypecash}</td>
                              <td>{incomedetail.vCurrencytype}</td>
                              <td>{incomedetail?.iCurrencyrate}</td>
                              <td>{new Date(incomedetail.dIncomedate).toDateString()}</td>
                              <td>{incomedetail?.vDocumentpath}</td>
                            </tr>
                          )
                        })
                      }
                    </tbody>
                  </table>
                </div>
                </>
            }
            {searchfilter.serchon == "Transaction" &&defaultview==='Expense'&&
                <>
                <div className="col-12">
                <div className="d-flex justify-content-center">
<button className="col-2" onClick={()=>setDefaultview("Income")}>Income</button>
<button className="col-2">Expense</button>
                  </div>
                  <h1>Expense</h1>
                  <table  className="table table-bordered">
                    <thead>
                      <tr>
                        
                        <th>Expense Cash/Chaque </th>
                        <th>Amount</th>
                        <th>Expense Reason</th>
                        <th>Paid Date</th>
                        <th>Document</th>
                      </tr>
                    </thead>
                    <tbody>
                      {/* <tr>
            <td>1</td>
            <td>Cash</td>
            <td>1000</td>
            <td></td>
            <td>Electicity Bill</td>
          </tr> */}
                      {
                        expense.map((expensedetail, index) => {
                          console.log(expensedetail)
                          return (
                            <tr>
                              <td>{expensedetail.eGivenform}</td>
                              <td>{expensedetail.toalpaid}</td>
                              <td>{expensedetail.vexpensetype}</td>
                              <td>{new Date(expensedetail.dcreatedate).toDateString()}</td>
                              <td>{expensedetail.vDocumentpath}</td>
                            </tr>
                          )
                        })
                      }
                    </tbody>
                  </table>
                </div>
              </>

            }
          </div>
          {/* <div className="pagination">

<ReactPaginate
breakLabel="..."
nextLabel="next >"
onPageChange={handlePageClick}
pageRangeDisplayed={3}
pageCount={pageCount}
previousLabel="< previous"
renderOnZeroPageCount={null}
breakClassName={'page-item'}
breakLinkClassName={'page-link'}
containerClassName={'pagination'}
pageClassName={'page-item'}
pageLinkClassName={'page-link'}
previousClassName={'page-item'}
previousLinkClassName={'page-link'}
nextClassName={'page-item'}
nextLinkClassName={'page-link'}
activeClassName={'active'}


/>
</div> */}
        </div>
        <div className="px-5 py-2">
          {searchfilter.serchon == "Developer" &&
            <>
              <h1>Developers on Bench</h1>
              <table  className="table table-bordered">
                <thead>
                  <tr>
                    <th>Index</th>
                    <th>Name</th>
                  </tr>
                </thead>
                <tbody>
                  {
                    data.length > 0 ? data.map((listofusers, index) => {
                      console.log(listofusers)
                      return (
                        <tr>
                          <td>{index + 1}</td>
                          <td>{listofusers.vname}</td>
                        </tr>
                      )
                    }) : ""
                  }
                </tbody>
              </table>
            </>
          }
        </div>
        <div className="py-2">

          {searchfilter.serchon === "Sales" &&
            <>
              <h1>
                Sales
                  <span className="float-right" style={{float:'right'}}>
                    <div className="btn-group">
                      <button type="button" className={'btn '}>Apple</button>
                      <button type="button" className="btn">Samsung</button>
                      <button type="button" className="btn">Sony</button>
                    </div>
                  </span>
                </h1>
              <table  className="table table-bordered">
                <thead>
                  <tr>
                    <th>Index</th>
                    <th>Name</th>
                    <th >
                      Inquiry
                      <tr >
                        <td>Monthly</td>
                        <td>Weekly</td>
                        <td>Hourly</td>
                      </tr>
                    </th>
                    <th>Project
                      <tr>
                        <td>Monthly</td>
                        <td>Weekly</td>
                        <td>Hourly</td>
                      </tr>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {
                    data?.length > 0 ? data.map((listofusers, index) => {
                      return (
                        <tr>
                          <td>{index + 1}</td>
                          <td>{listofusers.username}</td>
                          <td>
                            <tr>
                              <td>{listofusers.inquiry_Monthly?listofusers.inquiry_Monthly:''}</td>
                              <td>{listofusers.inquiry_Weekly?listofusers.inquiry_Weekly:''}</td>
                              <td>{listofusers.inquiry_Hourly?listofusers.inquiry_Hourly:''}</td>
                            </tr>
                          </td>
                          <td>
                            <tr>
                              <td>{listofusers.project_Monthly?listofusers.project_Monthly:''}</td>
                              <td>{listofusers.project_Weekly?listofusers.project_Weekly:''}</td>
                              <td>{listofusers.project_Hourly?listofusers.project_Hourly:''}</td>
                            </tr>
                          </td>
                        </tr>
                      )
                    }) : ""
                  }
                </tbody>
              </table>
            </>
          }
        </div>

      </div>
    </div>



  );
};

export default Reports;
