import React from "react";
import "./not_found.css"

const Not_Found =()=>{

    return(
        <>
        <div id="main">
    	<div className="fof">
        		<h1>Error 404</h1>
    	</div>
</div>
        </>
    )

}
export default Not_Found