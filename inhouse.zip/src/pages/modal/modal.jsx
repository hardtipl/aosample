import React from 'react'

function modal() {
  return (
    <div>
        <div>
            <h4>Are you sure you want to edit?</h4>
        </div>
    </div>
  )
}

export default modal