export const technologylist=[
".NET MVC",
".NET CORE",
".NET C#",
"Python",
"Laravel / PHP",
"ReactJs",
"ReactNative",
"NodeJs",
"MERN",
"MEAN",
"Python Scrapping",
"SEO",
"Digital Marketing",
"Graphics Design",
"HTML Creation",
"DevOps",
"Flutter",
"Android",
"IOS",
"MongoDB/PL-SQL","Other"]
export const sourcelist=[
  "LinkedIn", "Twitter", "Instagram","Freelancer","Upwork","PPH","Refernce","Reference Existing Client","Bulk Email","Other"]
